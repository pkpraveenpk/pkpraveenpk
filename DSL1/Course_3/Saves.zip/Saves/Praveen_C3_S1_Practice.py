#!/usr/bin/env python
# coding: utf-8

# # Creating variables 

# In[39]:


rollno=111 #assigning int data type to variable 
print(id(rollno),rollno,type(rollno),sep="  ,  ")


# In[21]:


firstname="Praveen" #assigning string data type to variable 
print(id(firstname),firstname,type(firstname),sep="  ,  ")


# In[22]:


lastname="Kumar" #assigning string data type to variable 
print(id(lastname),lastname,type(lastname),sep="  ,  ")


# In[23]:


maxmarks=50 #assigning string data type to variable 
print(id(maxmarks),maxmarks,type(maxmarks),sep="  ,  ")


# In[94]:


fullname=firstname+" "+lastname
fullname


# # Naming a variable

# In[24]:


var1=2 #assigning int data type to variable 


# In[25]:


2var=2 #We are getting syntax error because a variable's name cannot start with a number


# In[26]:


var 2=2 #We are getting syntax error because a variable's name cannot have spaces between them 


# In[27]:


var$2=2 #We are getting syntax error because a variable's name cannot use special charatcers.


# 
# # Assigning values to the variables

# In[28]:


Class=15 #assigning int data type to variable 


# In[29]:


class=14#We get error because class is a inbuilt keyword in python


# In[30]:


DEF=12 #assigning int data type to variable 


# In[31]:


def=11#We are getting error because def is a inbuilt keyword and also casesensitive


# In[34]:


a=True #We are assigning a boolean value to a variable which is possible.


# In[33]:


b=false#since we have'nt enclosed string in " " we get this error because python consider.


# # Using id()

# In[69]:


marks=13.0 #We are assigning a float data type to a variable.
print(id(marks),marks,type(marks),sep="  ,  ")
marks=35.0
print(id(marks),marks,type(marks),sep="  ,  ")  
'''Replacing value of marks also we can see both id() values are different this
is because the values of all variables are unique for lifetime in global scope in
this case we have changed values from 13 to 18 thus they have changed'''


# In[70]:


print((marks/maxmarks)*100,"%") #String concantenation
print(firstname+" "+lastname)
print(firstname+" "+lastname+" scored "+str(marks/maxmarks*100)+"%")


# # Creating dictionary and list

# In[71]:


student_details={111:"Praveen Kumar",77:"Vijay",118:"Rahul"}
student_list=[rollno,firstname+" "+lastname,marks]
print(student_list)
'''Created a dictionary and list data structure '''


# # Arithmetic operations

# In[74]:


1+"2"
'''This is because we are trying to add two different data types since python is a strongly typed 
language it throws an error'''


# In[75]:


"1"+"2" #String concatenation 2 string objects can be added into one.


# In[80]:


1/2 
'''Returns a float value because / is division operator which returns float '''


# In[85]:


print(1//2)
'''Returns zero value because // is integer division since 0.5 is float zero is returned '''


# # Logical operations

# In[88]:


True and True
#"""The and operator returns true if and only if when both conditions given to it are True """


# In[89]:


True and False 
#"""The and operator returns true if and only if when both conditions given to it are True """


# In[90]:


True or False
#"""The or operator returns true even if one of the conditions given to it are True """


# In[92]:


False or False
#"""The or operator returns true even if one of the conditions given to it are True """


# # Identity and Membership

# In[96]:


print(firstname in fullname) #This is true because the in operator checks if given value is a constituent element. 


# In[97]:


print(firstname is fullname) #This is False because is operator checks if given value is same constituent element. 


# # Associativity

# In[102]:


a=4
b=3
c=2
d=a**b+c
e=a**(b+c)
print(e,d) #The answers are different due to order of precedence when we mention in brackets they get higher OP.


# # Area of circle

# In[109]:


area_of_circle=22/7*6**2
area_of_circle


# # Tax problem

# In[112]:


price=85
tax=85*18/100
total=tax+price
total


# In[ ]:





# # Dollars

# In[113]:


dollar=75
rupees=3333
total_dollars=rupees//dollar
total_dollars


# # Inflation

# In[115]:


cost=500
inflation=7/100
cost_year_ago=cost-cost*inflation
cost_year_ago

