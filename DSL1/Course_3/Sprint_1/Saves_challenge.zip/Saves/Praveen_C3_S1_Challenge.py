#!/usr/bin/env python
# coding: utf-8

# # Area of circle

# In[1]:


radius=6
area=22/7*6*6
area


# # Tax

# In[2]:


price=85
tax=85*18/100
total=tax+price
total


# # Dollars

# In[3]:


dollar=75
rupees=3333
total_dollars=rupees//dollar
total_dollars


# # Inflation

# In[4]:


cost=500
inflation=7/100
cost_year_ago=cost-cost*inflation
cost_year_ago


# # Welcome message 

# In[7]:


name=input("Enter you're name = ")
lang=input("Enter the language you're learning =")
print()
print("Hello I'm "+name+" and I'm learning "+lang)


# # Simple interest calculation 

# In[9]:


principal=int(input("Principal= "))
interest=int(input("interest= "))
tenure=int(input("Tenure= "))
SI=principal*tenure*intrest/100
print(SI)


# # Compound interest calculation

# In[15]:


principal=int(input("Principal= "))
interest=int(input("interest= "))
tenure=int(input("Tenure= "))
Amount=principal*(1+((intrest/100)*tenure))
CI=Amount-principal
print(CI)


# # Number swapping 

# In[16]:


numb1=int(input())
numb2=int(input())
print(numb1,numb2)
numb1,numb2=numb2,numb1
print(numb1,numb2)


# # Kilometer to miles 

# In[18]:


km=int(input("Enter km = "))
miles=km*0.62
print("In miles =",miles)


# # Creating tables 

# In[21]:


number=int(input("Enter the number = "))
for i in range(1,11):
    print(number,"x",i,"=",number*i)


# In[ ]:




